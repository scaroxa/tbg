using UnityEngine;

public class Playerscript : MonoBehaviour
{
    public Companion[] companions = new Companion[3];

    public int experience = 35;
    public int level = 1;
    public int floor = 1;
    public int gold = 20;
}
