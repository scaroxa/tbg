using UnityEngine;

public class Companion : MonoBehaviour
{
    public string companionname;
    public Sprite picture;
    public int hp, ap, atk, def, spd;
}
